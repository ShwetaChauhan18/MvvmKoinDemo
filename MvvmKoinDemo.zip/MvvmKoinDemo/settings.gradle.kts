rootProject.buildFileName = "build.gradle.kts"
include (":app")
