package com.shweta.mvvmkoindemo.di

import org.koin.dsl.module

val appModule = module {
}